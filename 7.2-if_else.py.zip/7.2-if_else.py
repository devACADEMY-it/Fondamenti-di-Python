#
# Fondamenti di Python 
# If e else
#
# Disponibile su devACADEMY.it
#

provaScritta=8
provaOrale=8
provaTecnica=6

if (provaScritta>=6 and provaOrale>=6
     and provaTecnica>=6):
      media=(provaScritta+provaOrale+provaTecnica)/3
      media=round(media,1)
      print('Promosso con la media {0}'.format(media))
else:
      print('Sei stato bocciato!')
