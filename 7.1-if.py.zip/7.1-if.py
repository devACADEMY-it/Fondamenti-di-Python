#
# Fondamenti di Python 
# If
#
# Disponibile su devACADEMY.it
#

provaScritta=8
provaOrale=5
provaTecnica=6

if (provaScritta>=6 and provaOrale>=6
     and provaTecnica>=6):
      media=(provaScritta+provaOrale+provaTecnica)/3
      media=round(media,1)
      print('Promosso con la media {0}'.format(media))
