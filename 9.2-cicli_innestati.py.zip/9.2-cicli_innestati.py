#
# Fondamenti di Python 
# Cicli innestati
#
# Disponibile su devACADEMY.it
#

for x in range(1, 11):
      for y in range(1,11):
            print(x*y, end='\t')
      print('\n')
