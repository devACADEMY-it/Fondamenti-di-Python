#
# Fondamenti di Python 
# Cicli for
#
# Disponibile su devACADEMY.it
#

#for x in range(10, 1, -1):
for x in ['cane', 'gatto', 'topo', 'gallo', 'mucca']:
      print(x)
