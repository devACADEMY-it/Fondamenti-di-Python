#
# Fondamenti di Python 
# Esempio riepilogativo operatori aritmetici
#
# Disponibile su devACADEMY.it
#

voto1=8
voto2=6
voto3=7.5

somma=voto1+voto2+voto3
media=somma/3
risultato=round(media, 1)
print(risultato)
