#
# Fondamenti di Python 
# Cicli while
#
# Disponibile su devACADEMY.it
#

contatore=1

while contatore<=10:
      #print('Ciao mondo!')
      print('Iterazione n. '+str(contatore))
      contatore+=1

print('\n FINE PROGRAMMA')
