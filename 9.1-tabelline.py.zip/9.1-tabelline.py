#
# Fondamenti di Python 
# Calcolo di tabelline
#
# Disponibile su devACADEMY.it
#

testo=input('Numero: ')
if testo.isdigit() and int(testo)>0:
      numero=int(testo)
      for x in range(1,11):
            riga='{0} X {1} = {2}'.format(numero, x, numero*x)
            print(riga)
else:
      print('Errore, richiesto un numero intero maggiore di 0')
      
