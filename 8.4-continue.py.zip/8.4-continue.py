#
# Fondamenti di Python 
# Controllo di un ciclo con continue
#
# Disponibile su devACADEMY.it
#

for n in range(1, 51):
      if n%5!=0:
            continue
      print(n)
