#
# Fondamenti di Python 
# Operatore ternario
#
# Disponibile su devACADEMY.it
#

provaScritta=3
provaOrale=4
provaTecnica=6

insufficienze=0

insufficienze+= 1 if provaScritta<6 else 0
insufficienze+= 1 if provaOrale<6 else 0
insufficienze+= 1 if provaTecnica<6 else 0
      
if insufficienze==0:
      media=(provaScritta+provaOrale+provaTecnica)/3
      media=round(media,1)
      print('Promosso con la media {0}'.format(media))
else:
      print('Hai {0} insufficienze. Sei stato bocciato'
            .format(insufficienze))
