#
# Fondamenti di Python 
# If elif else
#
# Disponibile su devACADEMY.it
#

provaScritta=3
provaOrale=2
provaTecnica=5

insufficienze=0

insufficienze+= 1 if provaScritta<6 else 0
insufficienze+= 1 if provaOrale<6 else 0
insufficienze+= 1 if provaTecnica<6 else 0
      
if insufficienze==0:
      media=(provaScritta+provaOrale+provaTecnica)/3
      media=round(media,1)
      print('Promosso con la media {0}'.format(media))
elif insufficienze==1:
      print('Hai 1 insufficienza. Sarai contattato per ripetere la prova')
elif insufficienze==2:
      print('Devi ripetere l\'esame a settembre')
else:
      print('Hai 3 insufficienze. Sei stato bocciato')
