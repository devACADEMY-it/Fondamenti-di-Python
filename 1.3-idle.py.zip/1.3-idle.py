#
# Fondamenti di Python 
# Il primo programma in IDLE
#
# Disponibile su devACADEMY.it
#

print('Ciao mondo!')
