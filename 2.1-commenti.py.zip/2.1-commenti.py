#
# Fondamenti di Python 
# Commenti
#
# Disponibile su devACADEMY.it
#

# stampa della frase "Ciao mondo!"
""" La seguente funzione
      stampa una stringa
      in questo caso "Ciao mondo!"
"""
print('Ciao mondo!')
