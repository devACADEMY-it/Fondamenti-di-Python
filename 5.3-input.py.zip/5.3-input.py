#
# Fondamenti di Python 
# La funzione input
#
# Disponibile su devACADEMY.it
#

nome=input('Come ti chiami ?  ')
print('Ciao '+nome)
