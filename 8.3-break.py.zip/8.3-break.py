#
# Fondamenti di Python 
# Controllo di un ciclo con break
#
# Disponibile su devACADEMY.it
#

testo='Inserire un valore ("fine" per uscire)'

while(True):
      valore=input(testo)
      if valore=='fine':
            print('Fine del programma')
            break
      print(int(valore)*3)
